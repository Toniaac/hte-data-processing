# for opentrons code, present very simple interface only for sample crafting
# I'm putting this off because it scares me but it should be mostly done, really just need to copy the old code into here and maybe add some helper functions
import time
from opentrons import protocol_api
import opentrons.execute
import opentrons.simulate

stock_weight_percent = 17
solution_slot_no = 9
solution_well_no = 0
solvent_slot_no = 6
solvent_well_no = 0
heater_slot_no = 11

dict_labware = {
                1: 'amlab_cast_stage_v6',
#                6: 'amlab_24_aluminumblock_2000ul_cap',
                8: 'amlab_96_tiprack_1000ul_v3',
#                7: 'pyrex_1_reservoir_50000ul',
                6: 'pyrex_1_reservoir_50000ul',
                9: 'pyrex_1_reservoir_50000ul',
                11: 'amlab_24_aluminumblock_2000ul_cap',
                }

conf = {
        "viscous":{
                    "asp_rate": 3, "asp_delay": 30, "asp_with": 1, 
                    "disp_rate": 3, "disp_delay": 30, "disp_air_delay": 0.1, "disp_with": 1, "blowout_rate": 8,
                    "mix_asp_rate": 15, "mix_disp_rate": 15, "mix_delay": 0.1, "mix_times": 10, "mix_vol": 820,
                    "air_gap": 10},

                "non-viscous": {
                    "asp_rate": 200, "asp_delay": 0.1, "asp_with": 10,
                    "disp_rate": 400, "disp_delay": 0.1, "disp_air_delay": 0, "disp_with": 10, "blowout_rate": 1000,
                    "mix_asp_rate": 200, "mix_disp_rate": 400, "mix_delay": 0.1, "mix_times": 10, "mix_vol": 820,
                    "air_gap": 10},

                "positional": { ## DO NOT CHANGE UNDER ANY ANY ANY CIRCUMSTANCES!!!
                    "bot_margin_jar": 2,
                    "bot_margin_general": 2
                }
        }

class OT2:
    def __init__(self, dict_of_labware = dict_labware, 
                 #position: Position, 
                 heater:bool = False, tip_index = 0, heater_well_index = 0): # maybe add option to customise the pipette later
        """
        USAGE GUIDELINES:
            It is up to the user's discretion to attach or de-attach a pipette. All of the functions here assume that
                a pipette has been attached.
            Attaching and de-attaching a pipette may be accomplished by the relevant methods provided by this class:
                _attach and _drop.
        """
        # for now the default tiprack location is in slot 8 - multiple default slots can be added
        self.protocol = opentrons.execute.get_protocol_api('2.11')
        
        # configure tipracks and pipette
        self.tipracks = [self.protocol.load_labware(dict_of_labware[8], "8")]
        self.pipette = self.protocol.load_instrument('p1000_single_gen2', 'left', tip_racks=self.tipracks)
        
        # configure everything that is not a tiprack
        self.labware = {}
        self.labware[8] = self.tipracks[0] # placeholder, need sth more concrete esp if multiple tipracks involved
        self.temp_mod = None
        for labware_slot in dict_of_labware:
            if (heater and "aluminumblock" in dict_of_labware[labware_slot]):
                # position the well block on top of the heater
                # crude, but idt anything else needs to be heated, and we only have one heater to begin with...
                # this also assumes that there is only one aluminum block. multiple may be printed in the future - must adjust.
                self.temp_mod = self.protocol.load_module(module_name = "temperature module gen2", location=labware_slot)
                self.temp_wells = self.temp_mod.load_labware(dict_of_labware[labware_slot])
                self.labware[labware_slot] = self.temp_wells
            elif (labware_slot != 8):
                self.labware[labware_slot] = self.protocol.load_labware(dict_of_labware[labware_slot], str(labware_slot))
    
        # home the pipette and reference position object
        self.protocol.home()
        #self.position = position
        
        # set config variable
        self.pipette.flow_rate.aspirate = 1
        self.pipette.flow_rate.dispense = 1
        self.var = conf

        self.tip_index = tip_index
        self.heater_well_index = heater_well_index
        
    # tier 1 functions
    def _set_temp(self, temp: float):
        assert self.temp_mod is not None
        self.temp_mod.set_temperature(temp)
        
    def _deactivate_temp(self):
        assert self.temp_mod is not None
        self.temp_mod.deactivate()
    
    def _attach(self, slot_no = None, well_no = None):
        """
        Attaches a pipette tip to the pipette.
        """
        # figure out this functionality!!!
        inc = 0
        while((inc<len(self.pipette.tip_racks)-1) and (self.pipette.tip_racks[inc].next_tip() is not None)):
            inc+=1

        if (slot_no and (well_no >= 0)):
            self.pipette.pick_up_tip(self.labware[slot_no].wells()[well_no])

        else:
            self.pipette.pick_up_tip()
    
    def attach_next_tip(self, slot_no = 8):
        self._attach(slot_no, self.tip_index)
        self.tip_index += 1

    def _drop(self, slot_no = None, well_no = None):
        """
        Drops a pipette tip in a specified slot number and well number. When none are provided, or None is supplied,
            the pipette tip is dropped in the trash.
        It is up to the user to ensure that the labware in the slot number indicated by slot_no is a tip rack.
        """
        if (slot_no and (well_no >= 0)):
            self.pipette.drop_tip(self.labware[slot_no].wells()[well_no])
        else:
            self.pipette.drop_tip()
        
    def _blowout(self, viscous: bool = True):
        """
        Blows out the pipette.
            viscous: bool. Specify true if viscous settings are to be used.
        """
        viscosity = "viscous"
        if (not viscous):
            viscosity = "non-viscous"

        def_pipette = self.pipette.flow_rate.blow_out
        self.pipette.flow_rate.blow_out = self.var[viscosity]["blowout_rate"]
        self.pipette.blow_out()
        self.pipette.flow_rate.blow_out = def_pipette # reset to default blow out rate
           
    def _aspirate_air(self, slot_no, well_no, viscous: bool = True):
        """
        Aspirates air into the pipette. The volume of air aspirated must be constant between different air aspirations
            and can be controlled via conf.ot_var.
        """
        well = self.labware[slot_no].wells()[well_no]
        viscosity = "viscous"
        if (not viscous):
            viscosity = "non-viscous"

        self.pipette.aspirate(self.var[viscosity]["air_gap"], well.top(z=10), rate = self.var[viscosity]["asp_rate"])
    
    def _aspirate(self, slot_no, well_no, vol, viscous: bool = True, for_mixing: bool = False, position: str = "bottom", debug_bypass = 0, lift_after_aspirate=True):
        """
        Aspirates liquid into the pipette.
            viscous: bool. Specify true if viscous settings are to be used.
            for_mixing: bool. Specify true if this is to be used as part of a mixing process. This
                should only be used internally as part of _mix.
        """
        well = self.labware[slot_no].wells()[well_no]
        viscosity = "viscous"
        if (not viscous):
            viscosity = "non-viscous"
        bot_adj = 1
        asp_rate = self.var[viscosity]["asp_rate"]
        if (for_mixing):
            asp_rate = self.var[viscosity]["mix_asp_rate"]
            bot_adj = 4
        if (position != "bottom"): # elevated, if we have more settings next time use a map
            bot_adj += 3 # used to be 7

        # set the z
        if ("pyrex" in self.labware[slot_no].load_name):
            z = self.var["positional"]["bot_margin_jar"] + bot_adj
        else:
            z = self.var["positional"]["bot_margin_general"] + bot_adj

        self.pipette.aspirate(vol, rate=asp_rate, location=well.bottom(z=z))
        
        if (not for_mixing and lift_after_aspirate):
            top_offset = 0
            if debug_bypass == 1:
                  top_offset = 0
            print("entered if statement!!!")
            self.pipette.move_to(well.top(z=top_offset), speed = self.var[viscosity]["asp_with"])
        self.protocol.delay(self.var[viscosity]["asp_delay"])
        
        
    
    def _dispense(self, slot_no, well_no, vol, viscous: bool = True, for_mixing: bool = False, blow_out: bool = True, \
                  before_air: bool = False, position: str = "bottom"): # dispense custom height?
        """
        Dispenses liquid from the pipette.
            viscous: bool. Specify true if viscous settings are to be used.
            for_mixing: bool. Specify true if this is to be used as part of a mixing process. This
                should only be used internally as part of _mix.
            blow_out: bool. Specify true if the pipette is to blow out after this dispense.
            before_air: bool. Specify true if the pipette is blowing out before aspirating air.
            position: string. Specify "top" if the dispense is to happen at the top of the well.
                    Specify "bottom" if the dispense is to happen at the bottom of the well.
        """
        viscosity = "viscous"
        if (not viscous):
            viscosity = "non-viscous"

        # make well
        well = self.labware[slot_no].wells()[well_no]

        # air aspiration configuration
        if (before_air):
            blow_out = False
        
        # mixing configuration
        bot_adj = 4
        disp_rate = self.var[viscosity]["disp_rate"]
        if (for_mixing):
            disp_rate = self.var[viscosity]["mix_disp_rate"]
            bot_adj = 1
        
        if (not for_mixing): # Assumes that the only business a pipette would have to aspirate and dispense within a well for is to mix.
            self.pipette.move_to(well.top())
        
        # dispense in well at custom dispense flowrate
        if (position.lower() == "bottom"):
            # set the z
            if ("pyrex" in self.labware[slot_no].load_name):
                z = self.var["positional"]["bot_margin_jar"] + bot_adj
            else:
                z = self.var["positional"]["bot_margin_general"] + bot_adj
            self.pipette.move_to(well.bottom(z=z), speed=self.var["non-viscous"]["disp_with"])
            
        else: # dispense top
            # set the z
            if ("aluminumblock" in self.labware[slot_no].load_name): # come up with sth more distinctive...
                z = -40
            else:
                z = 0
            self.pipette.move_to(well.top(z=z), speed=self.var[viscosity]["disp_with"])

        self.pipette.dispense(vol, rate=disp_rate)    
        
        # allow the excess liquid in tip to settle towards tip orifice
        if (before_air and (self.var[viscosity]["disp_air_delay"]>0)):
            self.protocol.delay(self.var[viscosity]["disp_air_delay"])
        else:
            self.protocol.delay(self.var[viscosity]["disp_delay"])

        # lower the blowout rate
        if (blow_out):
            self._blowout(viscous = viscous)

        # movement in mixing is controlled in the _mix() routine.
        # if not mixing, move to the top of the well according to the viscosity setting.
        # note that high surface tension liquids SHOULD BE PIPETTED WITH VISCOUS SETTINGS.
        if (not for_mixing):
            self.pipette.move_to(well.top(z=0), speed=self.var[viscosity]["disp_with"])

    # tier 2 functions
    def _transfer(self, src_slot_no, src_well_no, dest_slot_no, dest_well_no, vol, viscous: bool = True, position: str = "bottom"):
        """
        Transfers liquid from two wells.
            viscous: bool. Specify true if viscous settings are to be used.
            position: string. Specify "top" if the dispense is to happen at the top of the well.
                    Specify "bottom" if the dispense is to happen at the bottom of the well.            
        """
        if (vol > self.pipette.max_volume):
            while(vol - self.pipette.max_volume >= 0):
                vol -= self.pipette.max_volume
                self._aspirate(src_slot_no, src_well_no, self.pipette.max_volume, viscous=viscous)
                self._dispense(dest_slot_no, dest_well_no, self.pipette.max_volume, viscous=viscous, position=position)
            
        self._aspirate(src_slot_no, src_well_no, vol, viscous=viscous)
        self._dispense(dest_slot_no, dest_well_no, vol, viscous=viscous, position=position)

    def _reverse_pipette(self, src_slot_no, src_well_no, dest_slot_no, dest_well_no, vasp = 1000, vdisp = 800, viscous = True, ret_liq_to_src = True, air_gap = False):
        """
        Aspirates an amount of liquid from one well and dispenses less of it in another.
            viscous: bool. Specify true if viscous settings are to be used.
            ret_liq_to_origin: bool. Specify true if the remainder of the liquid in the pipette is to be returned to the source container.
            air_gap: bool. Specify true if the dispense is to be followed with an air aspiration.
        """
        fin_disp = vasp - vdisp

        self._aspirate(src_slot_no, src_well_no, vasp, viscous = viscous)
        self._dispense(dest_slot_no, dest_well_no, vdisp, viscous = viscous, blow_out = False, position = "top", before_air = air_gap)
                                       
        if (air_gap):
            self._aspirate_air(dest_slot_no, dest_well_no, viscous = viscous)
            fin_disp += air_gap

        if (ret_liq_to_src):
            self._dispense(src_slot_no, src_well_no, fin_disp, viscous = viscous, blow_out = True, position = "top")

    def _mix(self, slot_no, well_no, viscous: bool = True, lift_after_aspirate=False): # btw be careful slot_no is one-based well-no is zero based
        """
        Mixes liquids in a well.
            viscous: bool. Specify true if viscous settings are to be used.
        """          
        start = time.perf_counter()
        
        viscosity = "viscous"
        if (not viscous):
            viscosity = "non-viscous"

        for i in range(self.var[viscosity]["mix_times"]):
            #aspirate in well at custom aspirate flowrate
            self._aspirate(slot_no, well_no, self.var[viscosity]["mix_vol"], viscous = viscous, for_mixing = True, lift_after_aspirate = False)
            self.protocol.delay(self.var[viscosity]["mix_delay"])
            
            print("aspirate", i, self.var[viscosity]["mix_times"])

            if (i != self.var[viscosity]["mix_times"]-1):
                #dispense in well at custome dispense flowrate
                self._dispense(slot_no, well_no, self.var[viscosity]["mix_vol"]/2, for_mixing = True, blow_out = False\
                               , viscous = viscous, position = "bottom")
                self._dispense(slot_no, well_no, self.var[viscosity]["mix_vol"]/2, for_mixing = True, blow_out = False\
                               , viscous = viscous, position = "top")

                #allow the excess liquid in tip to settle towards tip orifice
                self.protocol.delay(self.var[viscosity]["mix_delay"])
            else:
                self._dispense(slot_no, well_no, self.var[viscosity]["mix_vol"]/2, for_mixing = True, blow_out = False\
                               , viscous = viscous, position = "bottom")
                self._dispense(slot_no, well_no, self.var[viscosity]["mix_vol"]/2, for_mixing = True, blow_out = True\
                               , viscous = viscous, position = "top")
                self.protocol.delay(self.var[viscosity]["mix_delay"])
            
            # instead of not using mix settings, use mix settings but don't blow out
            # TODO
            
            print("dispense", i, self.var[viscosity]["mix_times"])
            
        # make well
        well = self.labware[slot_no].wells()[well_no]
        
        end = time.perf_counter()
        print(end-start)
        
    def prep_pullcast(self, slot_no, well_no, vol, viscous: bool = True):
        if (vol > 450):
            self._aspirate(slot_no, well_no, vol/2, viscous, position="elevated", lift_after_aspirate = False)
            self._aspirate(slot_no, well_no, vol/2, viscous, position="bottom")

            volumes = [vol/6 - 60, vol/6 - 20, vol/6 - 10, vol/6 + 10, vol/6 + 20, vol/6 + 60]
            for i in range(6):
                blow_out = False
                if (i==5): blow_out = True
                self._dispense(1, i, volumes[i], viscous = False, blow_out = blow_out)
        else:
            print("unsafe volume for pullcasting!")

    def prep_pullcast_from_mix(self, vol, viscous: bool = True):
        self.prep_pullcast(heater_slot_no, self.heater_well_index, vol)
        self.heater_well_index += 1

    # assume no pippette tip to begin, but does not drop tip at the end (we'll use the same tip for pullcast)
    def _prepare_solution(self, desired_weight_percent, total_vol, viscous: bool = True, position: str = "bottom"):
        rho_solution = 1.114867
        rho_solvent = 1.0148
        C_i = stock_weight_percent/100
        C_f = desired_weight_percent/100
        V_f = total_vol
        V_c = round(((C_i-C_f)*V_f*rho_solution)/(C_i*rho_solution - C_f*rho_solution + C_f*rho_solvent),0)
        V_i = round(V_f - V_c,0)
        print(f"Solvent: {V_c} uL", f"Solution: {V_i} uL")
        if total_vol > 1000:
            # raise error
            raise ValueError("Final volume cannot exceed 1000 µL.")
        
        # actually mix the solution
        if V_c != 0:
            self.attach_next_tip()
            self._transfer(solvent_slot_no, solvent_well_no, heater_slot_no, self.heater_well_index, V_c, False)
            self._drop()
            self.attach_next_tip()
            self._transfer(solution_slot_no, solution_well_no, heater_slot_no, self.heater_well_index, V_i)
            self._mix(heater_slot_no, self.heater_well_index)
        else: # no mixing required if desired weight percent is same as the stock
            self.attach_next_tip()
            self._transfer(solution_slot_no, solution_well_no, heater_slot_no, self.heater_well_index, V_i)
        
        
    def runhome(self):
        self.protocol.home()
        if self.pipette.has_tip:
            self.pipette.drop_tip()

    def get_stock_weight_percent(self):
        return stock_weight_percent
