import sys
sys.path.append("/var/lib/jupyter/notebooks/2025-07-02/lib/")
from arduino import Uno
arduino = Uno()
arduino.run_test()